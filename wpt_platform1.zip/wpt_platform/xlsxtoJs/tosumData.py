import openpyxl
import json

# 定义函数，将 Excel 数据转换为 sumData 格式
def convert_xlsx_to_sumdata(file_path):
    # 打开 Excel 文件
    workbook = openpyxl.load_workbook(file_path)
    sheet = workbook.active  # 获取活动工作表

    # 初始化 sumData 数据结构
    sumData = {"modules": []}

    # 遍历表格内容（跳过表头）
    for row in sheet.iter_rows(min_row=2, values_only=True):  # 从第2行开始读取数据
        module, _, note = row  # 分别对应模块、支持情况（忽略原始值）、备注

        # 根据 note 的内容设置 status
        if note.startswith("小部分支持") or note.startswith("不支持"):
            status = "not-supported"
        elif note.startswith("部分支持"):
            status = "partial-support"
        elif note.startswith("完全支持"):
            status = "supported"
        else:
            status = "unknown"  # 如果 note 不符合任何条件，设置为 unknown

        sumData["modules"].append({
            "module": module,
            "status": status,
            "note": note
        })

    return sumData

# 定义函数，将 Excel 数据转换为 detailData 格式
def convert_xlsx_to_detaildata(file_path):
    # 打开 Excel 文件
    workbook = openpyxl.load_workbook(file_path)
    sheet = workbook["统计报告"]  # 获取第一个工作表

    # 初始化 detailData 数据结构
    detailData = {"modules": []}

    # 初始化变量，用于存储合并单元格的值
    last_style = None
    last_default_value = None
    last_yes_value = None

    # 遍历表格内容（跳过表头）
    for row in sheet.iter_rows(min_row=2):  # 从第2行开始读取数据
        # 获取每列的值，处理合并单元格
        style = row[0].value if row[0].value is not None else last_style
        default_value = row[1].value if row[1].value is not None else last_default_value
        yes_value = row[2].value if row[2].value is not None else last_yes_value
        description = row[3].value  # 支持规格
        pass_rate = row[4].value  # WPT通过率
        pass_percent_rate = row[5].value  # 百分比

        # 更新合并单元格的值
        last_style = style
        last_default_value = default_value
        last_yes_value = yes_value

        # 添加到 detailData
        detailData["modules"].append({
            "style": style,
            "default_value": default_value,
            "yes_value": yes_value,
            "description": description,
            "pass_rate": pass_rate,
            "pass_percent_rate": pass_percent_rate,
            "detail_link": "跳转"
        })

    return detailData

# 定义函数，将 Excel 数据转换为 wptCaseData 格式
def convert_xlsx_to_wptcasedata(file_path):
    # 打开 Excel 文件
    workbook = openpyxl.load_workbook(file_path)

    # 初始化 wptCaseData 数据结构
    wptCaseData = {"modules": []}

    # 遍历所有工作表（跳过统计报告工作表）
    for sheet_name in workbook.sheetnames:
        if sheet_name == "统计报告":
            continue

        sheet = workbook[sheet_name]

        # 遍历表格内容（跳过表头）
        for row in sheet.iter_rows(min_row=2):  # 从第2行开始读取数据
            style = row[0].value  # 样式
            value = row[1].value  # 属性
            url = row[2].value  # 文件名
            type_ = row[3].value  # 关键词
            labels = row[4].value  # 标签
            description = row[5].value  # 描述
            ai_tip = row[6].value  # AI备注
            result = row[7].value  # 结果

            # 添加到 wptCaseData
            wptCaseData["modules"].append({
                "style": style,
                "value": value,
                "URL": url,
                "type": type_,
                "labels": labels,
                "description": description,
                "ai_tip": ai_tip,
                "result": result
            })

    return wptCaseData

# 定义函数，将转换后的数据写入 detailData.js 文件
def write_to_detaildata_js(detaildata, file_path):
    with open(file_path, "w", encoding="utf-8") as f:
        f.write("var detailData = ")
        f.write(json.dumps(detaildata, indent=4, ensure_ascii=False))
        f.write(";")  # 添加分号以符合 JavaScript 语法

# 定义函数，将转换后的数据写入 wptCaseData.js 文件
def write_to_wptcasedata_js(wptcasedata, file_path):
    with open(file_path, "w", encoding="utf-8") as f:
        f.write("var wptCaseData = ")
        f.write(json.dumps(wptcasedata, indent=4, ensure_ascii=False))
        f.write(";")  # 添加分号以符合 JavaScript 语法

# 定义函数，将转换后的数据写入 sumData.js 文件
def write_to_sumdata_js(sumdata, file_path):
    with open(file_path, "w", encoding="utf-8") as f:
        f.write("var sumData = ")
        f.write(json.dumps(sumdata, indent=4, ensure_ascii=False))
        f.write(";")  # 添加分号以符合 JavaScript 语法

# 主程序
if __name__ == "__main__":
    # 输入 Excel 文件路径
    xlsx_file_path = r"C:\\Users\\hpr13\\Desktop\\wpt_platform\\statistics.xlsx"  # 替换为你的 Excel 文件路径
    sumdata_js_path = r"C:\\Users\\hpr13\\Desktop\\wpt_platform\\sumData.js"  # 替换为你的 sumData.js 文件路径

    # 转换 sumData 数据
    sumData = convert_xlsx_to_sumdata(xlsx_file_path)

    # 写入 sumData.js 文件
    write_to_sumdata_js(sumData, sumdata_js_path)

    print(f"已将转换后的 sumData 数据写入 {sumdata_js_path}")

    # 输入 Excel 文件路径
    detail_xlsx_file_path = r"C:\\Users\\hpr13\\Desktop\\wpt_platform\\detail_statistics.xlsx"  # 替换为你的 Excel 文件路径
    detaildata_js_path = r"C:\\Users\\hpr13\\Desktop\\wpt_platform\\detailData.js"  # 替换为你的 detailData.js 文件路径
    wptcasedata_js_path = r"C:\\Users\\hpr13\\Desktop\\wpt_platform\\wptCaseData.js"  # 替换为你的 wptCaseData.js 文件路径

    # 转换 detailData 数据
    detailData = convert_xlsx_to_detaildata(detail_xlsx_file_path)

    # 写入 detailData.js 文件
    write_to_detaildata_js(detailData, detaildata_js_path)
    print(f"已将转换后的 detailData 数据写入 {detaildata_js_path}")

    # 转换 wptCaseData 数据
    wptCaseData = convert_xlsx_to_wptcasedata(detail_xlsx_file_path)

    # 写入 wptCaseData.js 文件
    write_to_wptcasedata_js(wptCaseData, wptcasedata_js_path)
    print(f"已将转换后的 wptCaseData 数据写入 {wptcasedata_js_path}")