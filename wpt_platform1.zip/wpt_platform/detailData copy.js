var detailData={
    "modules": [
        {
            "style": "inset",
            "default_value": "auto",
            "yes_value": "auto",
            "description": "【支持】基础标准用法和性质",
            "pass_rate": "4/4",
            "pass_percent_rate": "100%",
            "detail_link": "跳转"
        },
        {
            "style": "inset",
            "default_value": "auto",
            "yes_value": "auto",
            "description": "【支持】标签或样式结合",
            "pass_rate": "4/4",
            "pass_percent_rate": "100%",
            "detail_link": "跳转"
        },
        {
            "style": "inset",
            "default_value": "auto",
            "yes_value": "length",
            "description": "【支持】基础标准用法和性质",
            "pass_rate": "4/4",
            "pass_percent_rate": "100%",
            "detail_link": "跳转"
        },
        {
            "style": "inset",
            "default_value": "auto",
            "yes_value": "length",
            "description": "【支持】标签或样式结合",
            "pass_rate": "4/4",
            "pass_percent_rate": "100%",
            "detail_link": "跳转"
        },
        {
            "style": "inset",
            "default_value": "auto",
            "yes_value": "others",
            "description": "【支持】基础标准用法和性质",
            "pass_rate": "4/4",
            "pass_percent_rate": "100%",
            "detail_link": "跳转"
        },
        {
            "style": "inset",
            "default_value": "auto",
            "yes_value": "percentage",
            "description": "【支持】基础标准用法和性质",
            "pass_rate": "4/4",
            "pass_percent_rate": "100%",
            "detail_link": "跳转"
        },
        {
            "style": "background",
            "default_value": "auto",
            "yes_value": "percentage",
            "description": "【支持】基础标准用法和性质",
            "pass_rate": "4/4",
            "pass_percent_rate": "100%",
            "detail_link": "跳转"
        },
    ]
}