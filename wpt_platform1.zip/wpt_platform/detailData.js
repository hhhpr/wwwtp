var detailData = {
    "modules": [
        {
            "style": "background",
            "default_value": "normal",
            "yes_value": "baseline",
            "description": "【支持】基础标准用法和性质",
            "pass_rate": "1/9",
            "pass_percent_rate": 0.5,
            "detail_link": "跳转"
        },
        {
            "style": "background",
            "default_value": "normal",
            "yes_value": "baseline",
            "description": "【不支持】标签或样式结合",
            "pass_rate": "0/1",
            "pass_percent_rate": 0.3,
            "detail_link": "跳转"
        },
        {
            "style": "background",
            "default_value": "normal",
            "yes_value": "center",
            "description": "【部分支持】基础标准用法和性质",
            "pass_rate": "22/33",
            "pass_percent_rate": 0.4,
            "detail_link": "跳转"
        },
        {
            "style": "background",
            "default_value": "normal",
            "yes_value": "center",
            "description": "【部分支持】标签或样式结合",
            "pass_rate": "45/98",
            "pass_percent_rate": 0.6,
            "detail_link": "跳转"
        },
        {
            "style": "background",
            "default_value": "normal",
            "yes_value": "none",
            "description": "【不支持】标签或样式结合",
            "pass_rate": "4/7",
            "pass_percent_rate": 0.982,
            "detail_link": "跳转"
        },
        {
            "style": "background",
            "default_value": "normal",
            "yes_value": "auto",
            "description": "【不支持】标签或样式结合",
            "pass_rate": "9/9",
            "pass_percent_rate": 0.12,
            "detail_link": "跳转"
        },
        {
            "style": "background-clip",
            "default_value": "normal",
            "yes_value": "baseline",
            "description": "【支持】基础标准用法和性质",
            "pass_rate": "1/9",
            "pass_percent_rate": 0.5,
            "detail_link": "跳转"
        },
        {
            "style": "background-clip",
            "default_value": "normal",
            "yes_value": "baseline",
            "description": "【不支持】标签或样式结合",
            "pass_rate": "0/1",
            "pass_percent_rate": 0.3,
            "detail_link": "跳转"
        },
        {
            "style": "background-clip",
            "default_value": "normal",
            "yes_value": "center",
            "description": "【部分支持】基础标准用法和性质",
            "pass_rate": "22/33",
            "pass_percent_rate": 0.4,
            "detail_link": "跳转"
        },
        {
            "style": "background-clip",
            "default_value": "normal",
            "yes_value": "center",
            "description": "【部分支持】标签或样式结合",
            "pass_rate": "45/98",
            "pass_percent_rate": 0.6,
            "detail_link": "跳转"
        }
    ]
};