var sumData = {
    "modules": [
        {
            "module": "background",
            "status": "not-supported",
            "note": "小部分支持，总体支持率50%"
        },
        {
            "module": "background-clip",
            "status": "unknown",
            "note": "大部分支持，总体支持率90%"
        },
        {
            "module": "background-origin",
            "status": "unknown",
            "note": "大部分支持，总体支持率90%"
        },
        {
            "module": "background-color",
            "status": "supported",
            "note": "完全支持"
        }
    ]
};