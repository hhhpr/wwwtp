var sumData={
    "modules": [
        {
            "module": "inset",
            "status": "supported",
            "note": "v0.78+ 基础功能"
        },
        {
            "module": "CSS Grid",
            "status": "partial-support",
            "note": "实验性功能"
        },
        {
            "module": "暗黑模式",
            "status": "supported",
            "note": "需系统级支持"
        },
        {
            "module": "CSS变量",
            "status": "not-supported",
            "note": "计划v0.85+"
        },
        {
            "module": "动画过渡",
            "status": "partial-support",
            "note": "仅支持transform"
        }
    ]
}

var chartData={
    "modules": [
        ["2025-03-15","2025-03-30","2025-04-01","2025-04-05","2025-04-16",],
        [20, 30, 40, 50, 60],
    ],
}